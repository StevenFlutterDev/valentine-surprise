/**
 * ─────────────────────────────────────────────────────────────
 *  All the words live here.
 *  Edit anything in this file and the whole site updates.
 * ─────────────────────────────────────────────────────────────
 */

export const her = {
  fullName: "Angel Tan Lee Ying",
  firstName: "Angel",
  /** Shown letter-by-letter during the opening animation */
  introEyebrow: "For my wife,",
  introSubtitle: "three years of love, of giving, of you.",
  enterLabel: "Open my heart",
};

export const hero = {
  eyebrow: "Happy Valentine's Day",
  title: "Angel Tan Lee Ying",
  subtitle:
    "Three years a wife. Three years a mother. Three years of quietly giving more than anyone will ever know.",
  scrollCue: "scroll, my love",
};

export const stats = [
  { value: 3, suffix: "", label: "years of us" },
  { value: 1095, suffix: "", label: "days you chose us" },
  { value: 1, suffix: "", label: "heart that holds it all" },
];

export const sections = [
  {
    id: "quiet-hours",
    kicker: "01 — The quiet hours",
    heading: "There is a love the world never sees.",
    body: [
      "It happens at three in the morning, in a dim room, with a small warm body on your shoulder and your own tiredness set gently aside.",
      "You have carried those hours for three years, Angel. You never once asked for credit for a single one of them.",
    ],
  },
  {
    id: "what-you-gave",
    kicker: "02 — What you gave up",
    heading: "You gave away pieces of yourself, and called it normal.",
    body: [
      "Late mornings. Hot meals. Long showers. Whole chapters of your own plans, quietly folded away and put on a shelf.",
      "Not because anyone asked you to — but because you decided, over and over, that we were worth it. I have watched you choose us every single day.",
    ],
  },
  {
    id: "what-you-built",
    kicker: "03 — What you built",
    heading: "A home is not a house.",
    body: [
      "It is something warm in the kitchen. Laundry folded before anyone notices. A child who feels safe. A husband who feels loved.",
      "You built all of it with your own two hands and you made it look effortless. It was never effortless. I know.",
    ],
  },
];

export const years = [
  {
    year: "Year One",
    title: "The beginning",
    text: "We learned each other. You learned to be a mother — and I learned what love looks like when it stops sleeping.",
  },
  {
    year: "Year Two",
    title: "The building",
    text: "Long days, small victories, and you holding all of it together with a patience I still don't quite understand.",
  },
  {
    year: "Year Three",
    title: "The becoming",
    text: "More yourself than ever, and somehow still giving more than anyone. I have never been prouder of a person in my life.",
  },
];

export const letter = {
  hint: "tap the envelope",
  salutation: "My dearest Angel,",
  lines: [
    "Three years ago you said yes to a life with me — and then you quietly said yes a thousand more times. Yes to every early morning. Yes to every missed meal. Yes to every night you stayed awake so someone else could rest.",
    "I know how much you carry. I see it, even on the days I forget to say it out loud.",
    "You are the reason this house feels like home. You are the reason our little one laughs so freely. You are the reason I still cannot believe my luck.",
    "Thank you for everything you have given up for us. I promise to spend the rest of my life giving it back to you.",
    "I love you. Today, and every single day after.",
  ],
  signOff: "Always yours,",
  signature: "Your husband",
};

export const finale = {
  small: "and so —",
  big: "Thank you, Angel.",
  sub: "For three years of a love that never asked for anything back.",
  footer: "Three years down. Forever to go. 💗",
  tapHint: "tap anywhere — the hearts are for you",
};
